/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package databaseproject;

/**
 * @author kevinsanchez
 */

public class  DatabaseProject {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {

        JFrameLogin home = new JFrameLogin();
        home.show();

    }
}
